import React, { useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Philosophy from './components/Philosophy';
import Analytics from './components/Analytics';
import AIStack from './components/AIStack';
import Prototyping from './components/Prototyping';
import Strategy from './components/Strategy';
import Frameworks from './components/Frameworks';
import WhyMe from './components/WhyMe';
import Footer from './components/Footer';

export default function App() {
  // Smooth scroll behavior is handled by CSS in index.html, 
  // but we ensure standard browser behavior here.
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-white relative">
      <Navbar />
      
      <main>
        <Hero />
        <Frameworks />
        <Philosophy />
        <Analytics />
        <AIStack />
        <Prototyping />
        <Strategy />
        <WhyMe />
      </main>

      <Footer />
    </div>
  );
}