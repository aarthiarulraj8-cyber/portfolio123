# Aarthi Arulraj - Chief of Staff Portfolio

This is a high-performance, single-page portfolio built with React and Tailwind CSS.

## How to Deploy on Vercel

1. **Create a GitHub Repository**:
   - Push this code to a new repository on your GitHub account.

2. **Login to Vercel**:
   - Go to [vercel.com](https://vercel.com) and log in.

3. **Import Project**:
   - Click "Add New" -> "Project".
   - Select the GitHub repository you just created.

4. **Configure Settings**:
   - Framework Preset: Vercel usually detects "Vite" or "Create React App" automatically. If not, select **Vite**.
   - Root Directory: `./` (default)
   - Build Command: `npm run build` (or `yarn build`)
   - Output Directory: `dist` (if using Vite) or `build` (if using CRA).

5. **Deploy**:
   - Click "Deploy". Vercel will build the site and provide you with a live URL.

## Features

- **Smooth Scrolling**: Native CSS smooth scrolling with offset handling.
- **Interactive Frameworks**: Tabbed interface for experience pillars.
- **Save as HTML**: Client-side snapshot functionality.
- **Responsive Design**: Mobile-first architecture using Tailwind.
