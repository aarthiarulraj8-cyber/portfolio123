import React from 'react';
import { Search, Presentation, Bot, Code2 } from 'lucide-react';

const AIStack: React.FC = () => {
  const tools = [
    {
      icon: <Search className="w-6 h-6 text-blue-400" />,
      color: "blue",
      title: "Research Engine",
      desc: "Using LLMs to compress 6 hours of market research into 20 minutes of validated insights.",
      stat: "Time Saved: ~5.5 hrs"
    },
    {
      icon: <Presentation className="w-6 h-6 text-purple-400" />,
      color: "purple",
      title: "Deck Engine",
      desc: "Gamma + Polish. V1 in 30 minutes, V2 in an hour. Founder-ready narratives.",
      stat: "Speed: 4x Faster"
    },
    {
      icon: <Bot className="w-6 h-6 text-teal-400" />,
      color: "teal",
      title: "Agent Automation",
      desc: "Custom scripts to scrape, summarize, and cluster data. Reporting dropped from 4h to 7m.",
      stat: "Efficiency: 98%"
    },
    {
      icon: <Code2 className="w-6 h-6 text-orange-400" />,
      color: "orange",
      title: "Prototype Cycles",
      desc: "Building clickable tools in < 1 hour. Shortening idea → decision loops.",
      stat: "Output: Immediate"
    }
  ];

  return (
    <section id="ai-workflow" className="py-24 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-indigo-500 tracking-wider uppercase mb-2">02. Operational Leverage</h2>
          <h3 className="text-3xl font-bold mb-4">My Personal <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400">AI Stack</span></h3>
          <p className="text-slate-400 max-w-2xl mx-auto">AI isn't just a tool; it's an extension of my workflow. Here is how I reduce days of work into hours.</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tools.map((tool, index) => (
            <div key={index} className="group relative bg-slate-900 p-6 rounded-2xl border border-slate-800 hover:border-slate-700 transition-colors">
              <div className={`w-12 h-12 bg-${tool.color}-900/30 rounded-lg flex items-center justify-center mb-4`}>
                {tool.icon}
              </div>
              <h4 className="font-bold text-lg mb-2 text-white">{tool.title}</h4>
              <p className="text-sm text-slate-400 mb-4">{tool.desc}</p>
              <div className="text-xs font-mono text-green-400 bg-green-900/20 py-1 px-2 rounded inline-block">
                {tool.stat}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AIStack;