import React, { useState } from 'react';
import { AlertTriangle, Lightbulb, Rocket } from 'lucide-react';

const Analytics: React.FC = () => {
  const [fixed, setFixed] = useState(false);

  return (
    <section id="analytics" className="py-24 bg-slate-900 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="mb-12">
          <h2 className="text-sm font-bold text-indigo-500 tracking-wider uppercase mb-2">01. Analytical Rigor</h2>
          <h3 className="text-3xl font-bold">Turning Numbers into <span className="text-white">Narratives</span></h3>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-16">
          <div className="space-y-6">
            <div className="p-6 bg-slate-950 rounded-xl border-l-4 border-red-500 shadow-lg">
              <h4 className="text-red-400 font-bold mb-2 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" /> The Problem
              </h4>
              <p className="text-slate-400">In a previous role, we identified a <strong className="text-white">42% drop-off</strong> between "Activated" and "Value Achieved". Data was abundant, but insights were lagging.</p>
            </div>
            <div className="p-6 bg-slate-950 rounded-xl border-l-4 border-green-500 shadow-lg">
              <h4 className="text-green-400 font-bold mb-2 flex items-center gap-2">
                <Lightbulb className="w-5 h-5" /> The Insight
              </h4>
              <p className="text-slate-400">Through cohort analysis, I discovered users who <strong className="text-white">exported data</strong> within 5 minutes had <strong className="text-white">3.2x higher retention</strong>.</p>
            </div>
            <div className="p-6 bg-slate-950 rounded-xl border-l-4 border-indigo-500 shadow-lg">
              <h4 className="text-indigo-400 font-bold mb-2 flex items-center gap-2">
                <Rocket className="w-5 h-5" /> The Action
              </h4>
              <p className="text-slate-400">I led the redesign of onboarding to push exports immediately. Result: <strong className="text-white">Activation ↑ 18%</strong>, <strong className="text-white">Retention ↑ 27%</strong>.</p>
            </div>
          </div>
          
          {/* Interactive Chart */}
          <div className="bg-slate-950 rounded-2xl p-8 border border-slate-800 shadow-2xl flex flex-col justify-between">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h4 className="font-bold text-lg">Funnel Optimization</h4>
                <p className="text-xs text-slate-500">Cohort Analysis Example</p>
              </div>
              <label className="inline-flex items-center cursor-pointer">
                <span className="mr-3 text-sm font-medium text-slate-400">Baseline</span>
                <div className="relative">
                  <input type="checkbox" className="sr-only peer" checked={fixed} onChange={() => setFixed(!fixed)} />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                </div>
                <span className="ml-3 text-sm font-medium text-white">After Fix</span>
              </label>
            </div>
            
            <div className="space-y-6 flex-grow flex flex-col justify-center">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-300">Signed Up</span>
                  <span className="font-mono text-slate-300">100%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-4">
                  <div className="bg-indigo-500 h-4 rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-300">Activated</span>
                  <span className="font-mono text-slate-300">{fixed ? '68%' : '58%'}</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-4">
                  <div 
                    className={`h-4 rounded-full transition-all duration-1000 ${fixed ? 'bg-green-500 w-[68%]' : 'bg-indigo-500 w-[58%]'}`}
                  ></div>
                </div>
              </div>
              <div className="relative">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-300">Value Achieved (Retention)</span>
                  <span className={`font-mono transition-colors ${fixed ? 'text-green-400' : 'text-slate-300'}`}>
                    {fixed ? '47%' : '20%'}
                  </span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-4 relative">
                  <div 
                    className={`h-4 rounded-full transition-all duration-1000 relative ${fixed ? 'bg-green-500 w-[47%]' : 'bg-indigo-500 w-[20%]'}`}
                  >
                     {fixed && (
                        <div className="absolute right-0 -top-8 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded animate-bounce">
                        +27% Lift
                        </div>
                    )}
                  </div>
                </div>
                <p className={`text-xs mt-2 h-4 font-mono transition-colors ${fixed ? 'text-green-400' : 'text-red-400'}`}>
                    {fixed ? "✔ Retention optimized via early export triggers." : "⚠ Large drop-off detected here."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Analytics;