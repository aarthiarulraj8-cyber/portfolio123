import React, { useRef, useEffect } from 'react';

interface ChaosCanvasProps {
  systemized: boolean;
}

const ChaosCanvas: React.FC<ChaosCanvasProps> = ({ systemized }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = canvas.width = canvas.parentElement?.offsetWidth || 800;
    let height = canvas.height = canvas.parentElement?.offsetHeight || 400;

    let particles: Particle[] = [];
    let animationFrameId: number;

    class Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      targetX: number;
      targetY: number;
      size: number;
      color: string;

      constructor() {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = (Math.random() - 0.5) * 2;
        this.vy = (Math.random() - 0.5) * 2;
        this.targetX = 0;
        this.targetY = 0;
        this.size = 2.5;
        this.color = '#6366f1';
      }

      update(isSystemized: boolean, index: number, cols: number, cellW: number, cellH: number) {
        if (isSystemized) {
          const col = index % cols;
          const row = Math.floor(index / cols);
          this.targetX = col * cellW + cellW / 2;
          this.targetY = row * cellH + cellH / 2;
          
          this.x += (this.targetX - this.x) * 0.1;
          this.y += (this.targetY - this.y) * 0.1;
        } else {
          this.x += this.vx;
          this.y += this.vy;

          if (this.x < 0 || this.x > width) this.vx *= -1;
          if (this.y < 0 || this.y > height) this.vy *= -1;
        }
      }

      draw(context: CanvasRenderingContext2D, isSystemized: boolean) {
        context.beginPath();
        context.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        context.fillStyle = isSystemized ? '#4ade80' : this.color;
        context.fill();
      }
    }

    const init = () => {
      particles = [];
      for (let i = 0; i < 60; i++) {
        particles.push(new Particle());
      }
    };

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      const cols = 10;
      const rows = 6;
      const cellW = width / cols;
      const cellH = height / rows;

      if (systemized) {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;
        
        for(let i=0; i<=cols; i++) { 
          ctx.beginPath(); 
          ctx.moveTo(i*cellW, 0); 
          ctx.lineTo(i*cellW, height); 
          ctx.stroke(); 
        }
        for(let i=0; i<=rows; i++) { 
          ctx.beginPath(); 
          ctx.moveTo(0, i*cellH); 
          ctx.lineTo(width, i*cellH); 
          ctx.stroke(); 
        }
      }

      particles.forEach((p, i) => {
        p.update(systemized, i, cols, cellW, cellH);
        p.draw(ctx, systemized);
        
        // Connect particles in chaos mode
        if (!systemized) {
          particles.forEach(p2 => {
            const dx = p.x - p2.x;
            const dy = p.y - p2.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 100) {
              ctx.beginPath();
              ctx.strokeStyle = `rgba(99, 102, 241, ${0.1 - dist / 1000})`;
              ctx.moveTo(p.x, p.y);
              ctx.lineTo(p2.x, p2.y);
              ctx.stroke();
            }
          });
        }
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    const handleResize = () => {
        if(canvas.parentElement) {
            width = canvas.width = canvas.parentElement.offsetWidth;
            height = canvas.height = canvas.parentElement.offsetHeight;
            init();
        }
    }

    window.addEventListener('resize', handleResize);
    init();
    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [systemized]);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />;
};

export default ChaosCanvas;