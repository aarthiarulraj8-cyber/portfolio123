import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="py-8 bg-slate-950 text-center text-slate-600 border-t border-slate-900">
      <p className="text-sm">Built with React, Tailwind & Code. 2025.</p>
    </footer>
  );
};

export default Footer;