import React, { useState } from 'react';
import { TrendingUp, Wallet, Users, Target, BarChart3, Briefcase, ChevronRight } from 'lucide-react';

type TabType = 'cos' | 'strategy' | 'pgm' | 'analytics' | 'recruiting';

const Frameworks: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('cos');

  const tabs: { id: TabType; label: string }[] = [
    { id: 'cos', label: 'Chief of Staff' },
    { id: 'strategy', label: 'Strategy & Research' },
    { id: 'pgm', label: 'Program Mgmt' },
    { id: 'analytics', label: 'Analytics' },
    { id: 'recruiting', label: 'Recruiting' },
  ];

  return (
    <section id="frameworks" className="py-24 bg-slate-950 border-t border-slate-900 relative">
        <div className="absolute inset-0 opacity-5 pointer-events-none" style={{
            backgroundImage: `linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px)`,
            backgroundSize: '20px 20px'
        }}></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="mb-12 flex flex-col justify-between gap-6">
          <div>
            <h2 className="text-sm font-bold text-indigo-500 tracking-wider uppercase mb-2">05. Professional Experience</h2>
            <h3 className="text-3xl font-bold">Core <span className="text-white">Competencies</span></h3>
            <p className="text-slate-400 mt-2 max-w-xl">A deep dive into my operational expertise across five key pillars.</p>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 text-sm font-bold rounded-lg border transition-all ${
                  activeTab === tab.id 
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-500/20' 
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white hover:border-slate-600'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
        
        {/* Dashboard Display */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-1 min-h-[450px] shadow-2xl relative overflow-hidden">
          
          {/* Tab 1: Chief of Staff */}
          {activeTab === 'cos' && (
            <div className="p-6 animate-in fade-in slide-in-from-bottom-4 duration-500 h-full">
              <div className="grid md:grid-cols-3 gap-8 h-full">
                <div className="md:col-span-2 space-y-6">
                  <div className="flex items-center gap-3 mb-2">
                     <div className="p-2 bg-indigo-500/10 rounded-lg"><Briefcase className="text-indigo-400 w-6 h-6"/></div>
                     <h4 className="text-xl font-bold text-white">Office of the CEO</h4>
                  </div>
                  
                  <div className="grid sm:grid-cols-2 gap-4">
                     <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                        <h5 className="font-bold text-white mb-2">Board Management</h5>
                        <p className="text-sm text-slate-400">Orchestrating quarterly board meetings, creating decks, and managing investor communications and diligence data rooms.</p>
                     </div>
                     <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                        <h5 className="font-bold text-white mb-2">Executive Alignment</h5>
                        <p className="text-sm text-slate-400">Running OKR planning cycles, weekly leadership staff meetings, and ensuring cross-functional blockers are removed.</p>
                     </div>
                  </div>

                  <div className="bg-indigo-900/10 p-5 rounded-xl border border-indigo-500/20">
                     <h5 className="font-bold text-white mb-2">Strategic Initiatives</h5>
                     <ul className="space-y-2">
                        <li className="flex items-start gap-2 text-sm text-slate-300">
                            <ChevronRight className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                            <span>Led post-merger integration for 2 acquisitions ($50M+ value).</span>
                        </li>
                        <li className="flex items-start gap-2 text-sm text-slate-300">
                            <ChevronRight className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                            <span>Implemented company-wide operating cadence (All-hands, QBRs).</span>
                        </li>
                     </ul>
                  </div>
                </div>

                <div className="bg-slate-950 rounded-xl p-6 border border-slate-800 flex flex-col justify-between">
                   <div>
                       <h4 className="text-xs font-mono text-slate-500 uppercase tracking-widest mb-4">Focus Areas</h4>
                       <div className="space-y-4">
                           <div className="space-y-1">
                               <div className="flex justify-between text-sm text-white font-medium"><span>Bandwidth Expansion</span><span>High</span></div>
                               <div className="w-full bg-slate-800 h-1.5 rounded-full"><div className="bg-indigo-500 w-[95%] h-full rounded-full"></div></div>
                           </div>
                           <div className="space-y-1">
                               <div className="flex justify-between text-sm text-white font-medium"><span>Crisis Mgmt</span><span>High</span></div>
                               <div className="w-full bg-slate-800 h-1.5 rounded-full"><div className="bg-indigo-500 w-[90%] h-full rounded-full"></div></div>
                           </div>
                           <div className="space-y-1">
                               <div className="flex justify-between text-sm text-white font-medium"><span>Culture</span><span>Med</span></div>
                               <div className="w-full bg-slate-800 h-1.5 rounded-full"><div className="bg-indigo-500 w-[70%] h-full rounded-full"></div></div>
                           </div>
                       </div>
                   </div>
                   <div className="mt-6 pt-6 border-t border-slate-800">
                       <p className="text-xs text-slate-400 italic">"I act as a force multiplier for the executive team, ensuring vision translates to execution."</p>
                   </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Strategy & Research */}
          {activeTab === 'strategy' && (
             <div className="p-6 animate-in fade-in slide-in-from-bottom-4 duration-500 h-full">
             <div className="flex flex-col h-full">
               <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-purple-500/10 rounded-lg"><Target className="text-purple-400 w-6 h-6"/></div>
                    <h4 className="text-xl font-bold text-white">Strategy & Market Research</h4>
               </div>
               
               <div className="flex flex-col md:flex-row gap-8 items-center h-full">
                 <div className="w-full md:w-2/3 space-y-4">
                   <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl relative overflow-hidden group hover:border-purple-500/30 transition-colors">
                       <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                           <TrendingUp className="w-24 h-24 text-purple-500" />
                       </div>
                       <h5 className="text-lg font-bold text-white mb-2">Market Sizing (TAM/SAM/SOM)</h5>
                       <p className="text-sm text-slate-400 z-10 relative">I deploy rigorous top-down and bottom-up modeling to validate market opportunities. Experienced in sizing new verticals and geography expansions.</p>
                   </div>
                   
                   <div className="grid grid-cols-2 gap-4">
                        <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl">
                            <h5 className="font-bold text-white text-sm mb-1">Competitive Intel</h5>
                            <p className="text-xs text-slate-400">Feature gap analysis, pricing tear-downs, and win/loss analysis.</p>
                        </div>
                        <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl">
                            <h5 className="font-bold text-white text-sm mb-1">GTM Strategy</h5>
                            <p className="text-xs text-slate-400">Defining ICPs, persona mapping, and channel strategy.</p>
                        </div>
                   </div>
                 </div>
                 
                 <div className="w-full md:w-1/3 h-full bg-slate-950 border border-slate-800 rounded-xl p-6 flex flex-col justify-center">
                   <h5 className="text-white font-bold mb-4 text-center">Research Methodology</h5>
                   <div className="space-y-4">
                       <div className="flex items-center gap-3 text-sm text-slate-300">
                           <span className="w-6 h-6 rounded-full bg-purple-900/50 flex items-center justify-center text-xs font-mono">1</span>
                           Primary Research (Interviews)
                       </div>
                       <div className="h-4 w-0.5 bg-slate-800 ml-3"></div>
                       <div className="flex items-center gap-3 text-sm text-slate-300">
                           <span className="w-6 h-6 rounded-full bg-purple-900/50 flex items-center justify-center text-xs font-mono">2</span>
                           Data Validation (SQL/Surveys)
                       </div>
                       <div className="h-4 w-0.5 bg-slate-800 ml-3"></div>
                       <div className="flex items-center gap-3 text-sm text-slate-300">
                           <span className="w-6 h-6 rounded-full bg-purple-900/50 flex items-center justify-center text-xs font-mono">3</span>
                           Synthesis & Recommendation
                       </div>
                   </div>
                 </div>
               </div>
             </div>
           </div>
          )}

          {/* Tab 3: Program Mgmt */}
          {activeTab === 'pgm' && (
            <div className="p-6 animate-in fade-in slide-in-from-bottom-4 duration-500 h-full">
                <div className="grid md:grid-cols-2 gap-8 h-full">
                    <div className="space-y-6">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="p-2 bg-green-500/10 rounded-lg"><Wallet className="text-green-400 w-6 h-6"/></div>
                            <h4 className="text-xl font-bold text-white">Technical Program Management</h4>
                        </div>
                        <p className="text-slate-400">
                            Certified PMP/Agile practitioner. I don't just "manage projects"; I build the delivery infrastructure that allows engineering and product to ship faster.
                        </p>
                        <div className="space-y-3">
                            <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-lg">
                                <span className="text-slate-200 text-sm font-medium">JIRA / Linear Architecture</span>
                                <span className="text-xs bg-green-900/30 text-green-400 px-2 py-1 rounded">Advanced</span>
                            </div>
                            <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-lg">
                                <span className="text-slate-200 text-sm font-medium">Risk Mitigation</span>
                                <span className="text-xs bg-green-900/30 text-green-400 px-2 py-1 rounded">Proactive</span>
                            </div>
                            <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-lg">
                                <span className="text-slate-200 text-sm font-medium">Cross-Functional Comms</span>
                                <span className="text-xs bg-green-900/30 text-green-400 px-2 py-1 rounded">Expert</span>
                            </div>
                        </div>
                    </div>
                    <div className="bg-slate-950 rounded-xl border border-slate-800 p-6 flex items-center justify-center">
                         <div className="relative w-full max-w-xs">
                             <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-slate-800"></div>
                             <div className="space-y-8 relative">
                                 <div className="flex items-center gap-4">
                                     <div className="w-8 h-8 rounded-full bg-slate-800 border-2 border-green-500 flex items-center justify-center z-10 bg-slate-950">
                                         <span className="text-xs font-bold text-white">1</span>
                                     </div>
                                     <div className="bg-slate-800/50 p-2 rounded text-xs text-slate-300">Inception & Planning</div>
                                 </div>
                                 <div className="flex items-center gap-4">
                                     <div className="w-8 h-8 rounded-full bg-slate-800 border-2 border-green-500 flex items-center justify-center z-10 bg-slate-950">
                                         <span className="text-xs font-bold text-white">2</span>
                                     </div>
                                     <div className="bg-slate-800/50 p-2 rounded text-xs text-slate-300">Execution & Unblocking</div>
                                 </div>
                                 <div className="flex items-center gap-4">
                                     <div className="w-8 h-8 rounded-full bg-slate-800 border-2 border-green-500 flex items-center justify-center z-10 bg-slate-950">
                                         <span className="text-xs font-bold text-white">3</span>
                                     </div>
                                     <div className="bg-slate-800/50 p-2 rounded text-xs text-slate-300">Delivery & Retro</div>
                                 </div>
                             </div>
                         </div>
                    </div>
                </div>
            </div>
          )}

          {/* Tab 4: Analytics */}
          {activeTab === 'analytics' && (
            <div className="p-6 animate-in fade-in slide-in-from-bottom-4 duration-500 h-full">
                <div className="flex flex-col h-full">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="p-2 bg-blue-500/10 rounded-lg"><BarChart3 className="text-blue-400 w-6 h-6"/></div>
                        <h4 className="text-xl font-bold text-white">Analytics & Data Science</h4>
                    </div>
                    <div className="grid md:grid-cols-3 gap-6 h-full">
                        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col items-center text-center">
                            <div className="w-12 h-12 rounded-full bg-blue-900/20 flex items-center justify-center text-blue-400 mb-4 font-mono font-bold">SQL</div>
                            <h5 className="text-white font-bold">Data Extraction</h5>
                            <p className="text-xs text-slate-500 mt-2">Complex queries, CTEs, window functions. I get my own data.</p>
                        </div>
                        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col items-center text-center">
                            <div className="w-12 h-12 rounded-full bg-blue-900/20 flex items-center justify-center text-blue-400 mb-4 font-mono font-bold">BI</div>
                            <h5 className="text-white font-bold">Visualization</h5>
                            <p className="text-xs text-slate-500 mt-2">Tableau, Looker, Metabase. Building live executive dashboards.</p>
                        </div>
                        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col items-center text-center">
                            <div className="w-12 h-12 rounded-full bg-blue-900/20 flex items-center justify-center text-blue-400 mb-4 font-mono font-bold">PY</div>
                            <h5 className="text-white font-bold">Automation</h5>
                            <p className="text-xs text-slate-500 mt-2">Python/Pandas for data cleaning and recurring report automation.</p>
                        </div>
                    </div>
                    <div className="mt-6 bg-slate-950/50 p-4 rounded-lg border border-slate-800 border-dashed">
                        <p className="text-center text-sm text-slate-400">
                            "I don't just report numbers; I define the <strong>North Star Metrics</strong> that drive behavior."
                        </p>
                    </div>
                </div>
            </div>
          )}

          {/* Tab 5: Recruiting */}
          {activeTab === 'recruiting' && (
            <div className="p-6 animate-in fade-in slide-in-from-bottom-4 duration-500 h-full">
                 <div className="grid md:grid-cols-2 gap-8 h-full items-center">
                    <div className="space-y-6">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="p-2 bg-pink-500/10 rounded-lg"><Users className="text-pink-400 w-6 h-6"/></div>
                            <h4 className="text-xl font-bold text-white">Talent & Culture</h4>
                        </div>
                        <p className="text-slate-400">
                            Building high-performance teams is an engineering problem. I design hiring pipelines that optimize for signal-to-noise ratio.
                        </p>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-3 rounded bg-slate-950 border border-slate-800">
                                <div className="text-2xl font-bold text-white mb-1">45+</div>
                                <div className="text-xs text-slate-500 uppercase tracking-wide">Hires Managed</div>
                            </div>
                            <div className="p-3 rounded bg-slate-950 border border-slate-800">
                                <div className="text-2xl font-bold text-white mb-1">3 Days</div>
                                <div className="text-xs text-slate-500 uppercase tracking-wide">Avg. Time to Offer</div>
                            </div>
                        </div>
                    </div>
                    <div className="bg-slate-950 border border-slate-800 rounded-xl p-6">
                        <h5 className="text-white font-bold mb-4">Pipeline Architecture</h5>
                        <div className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                                <span className="text-slate-400">1. Sourcing Automation</span>
                                <span className="text-pink-400 font-mono">LinkedIn + Clay</span>
                            </div>
                            <div className="w-full bg-slate-800 h-1 rounded-full"><div className="bg-pink-500 w-full h-full rounded-full opacity-50"></div></div>
                            
                            <div className="flex items-center justify-between text-sm mt-2">
                                <span className="text-slate-400">2. Structured Interviewing</span>
                                <span className="text-pink-400 font-mono">Scorecards</span>
                            </div>
                            <div className="w-full bg-slate-800 h-1 rounded-full"><div className="bg-pink-500 w-[60%] h-full rounded-full opacity-50"></div></div>
                            
                            <div className="flex items-center justify-between text-sm mt-2">
                                <span className="text-slate-400">3. Onboarding</span>
                                <span className="text-pink-400 font-mono">30/60/90 Plans</span>
                            </div>
                            <div className="w-full bg-slate-800 h-1 rounded-full"><div className="bg-pink-500 w-[30%] h-full rounded-full opacity-50"></div></div>
                        </div>
                    </div>
                 </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Frameworks;