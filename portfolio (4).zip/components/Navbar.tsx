import React, { useState, useEffect } from 'react';
import { Bolt, Download } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleDownload = () => {
    // This creates a snapshot of the current DOM
    const htmlContent = document.documentElement.outerHTML;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Aarthi_Arulraj_Portfolio.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 border-b ${
      isScrolled 
        ? 'bg-slate-950/80 backdrop-blur-md border-slate-800' 
        : 'bg-transparent border-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <a 
            href="#"
            className="flex-shrink-0 flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity" 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <Bolt className="text-indigo-500 w-6 h-6" />
            <span className="font-bold text-lg tracking-tight">
              Aarthi Arulraj <span className="text-slate-500 font-normal text-sm">| Portfolio</span>
            </span>
          </a>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-6">
              {[
                { name: 'Competencies', id: 'frameworks' },
                { name: 'Philosophy', id: 'philosophy' },
                { name: 'Analytics', id: 'analytics' },
                { name: 'Strategy', id: 'strategy' },
                { name: 'Contact', id: 'why-me' }
              ].map((item) => (
                <a 
                  key={item.name}
                  href={`#${item.id}`}
                  className="hover:text-indigo-400 transition-colors px-2 py-2 text-sm font-medium text-slate-300 cursor-pointer"
                >
                  {item.name}
                </a>
              ))}
              
              <div className="flex items-center gap-2 ml-4">
                <button 
                  onClick={handleDownload} 
                  className="flex items-center gap-1 bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-lg hover:shadow-indigo-500/20"
                >
                  <Download className="w-3.5 h-3.5" />
                  Save HTML
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;