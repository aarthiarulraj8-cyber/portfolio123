import React, { useState } from 'react';
import { Gauge, Bot, Circle } from 'lucide-react';
import ChaosCanvas from './ChaosCanvas';

const Philosophy: React.FC = () => {
  const [systemized, setSystemized] = useState(false);

  return (
    <section id="philosophy" className="py-24 relative bg-slate-950 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-sm font-bold text-indigo-500 tracking-wider uppercase mb-2">The Founders Office</h2>
            <h3 className="text-4xl font-bold mb-6">From Chaos to <span className="text-indigo-400">System</span>.</h3>
            <p className="text-slate-400 text-lg mb-6 leading-relaxed">
              I operate at the intersection of operations, analytics, AI, and product strategy. As a Program Manager and CoS, my role is to take a half-formed idea from the founder and turn it into a repeatable, scalable engine.
            </p>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-indigo-900/30 rounded-lg text-indigo-400">
                    <Gauge className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white">Insight Velocity</h4>
                  <p className="text-sm text-slate-500">Accelerating the loop from data to decision.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="p-2 bg-purple-900/30 rounded-lg text-purple-400">
                    <Bot className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white">AI-Native Execution</h4>
                  <p className="text-sm text-slate-500">Using AI to multiply bandwidth and operational output.</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Interactive Chaos Visualization */}
          <div className="relative h-96 bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
            <ChaosCanvas systemized={systemized} />
            
            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center pointer-events-none">
              <div className="bg-slate-950/80 backdrop-blur px-4 py-2 rounded-lg border border-slate-800 pointer-events-auto">
                <span className={`text-xs font-mono font-bold ${systemized ? 'text-green-400' : 'text-red-400'}`}>
                  STATUS: {systemized ? 'SCALABLE SYSTEM' : 'CHAOS'}
                </span>
              </div>
              <button 
                onClick={() => setSystemized(!systemized)} 
                className="pointer-events-auto px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-bold rounded-lg shadow-lg shadow-indigo-500/20 transition-all flex items-center gap-2"
              >
                <Circle className={`w-3 h-3 ${systemized ? 'fill-current' : ''}`} />
                {systemized ? 'Reset Entropy' : 'Systemize'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Philosophy;