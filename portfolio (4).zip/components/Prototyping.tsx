import React, { useState, useEffect } from 'react';
import { FlaskConical, CheckCircle } from 'lucide-react';

const Prototyping: React.FC = () => {
  const [days, setDays] = useState(10);
  const [tickets, setTickets] = useState(2);
  const [exports, setExports] = useState(5);
  const [churnScore, setChurnScore] = useState(0);

  useEffect(() => {
    let score = (days * 1.5) + (tickets * 5) - (exports * 3);
    score = Math.max(0, Math.min(100, score));
    setChurnScore(Math.round(score));
  }, [days, tickets, exports]);

  const getScoreColor = (score: number) => {
    if (score > 60) return 'text-red-500';
    if (score > 30) return 'text-yellow-400';
    return 'text-white';
  };

  return (
    <section id="prototyping" className="py-24 bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 shadow-2xl">
              <div className="flex items-center justify-between mb-6 border-b border-slate-800 pb-4">
                <h4 className="font-bold text-white flex items-center gap-2">
                  <FlaskConical className="text-indigo-500 w-5 h-5" />
                  Prototype: Churn Predictor
                </h4>
                <span className="text-xs font-mono text-slate-500">v1.0.4 (48h Build)</span>
              </div>
              
              <div className="space-y-6">
                <div>
                  <label className="flex justify-between text-sm text-slate-400 mb-2">
                    Days Since Last Login
                    <span className="text-white font-mono">{days}</span>
                  </label>
                  <input 
                    type="range" min="0" max="60" value={days} 
                    onChange={(e) => setDays(Number(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500" 
                  />
                </div>
                <div>
                  <label className="flex justify-between text-sm text-slate-400 mb-2">
                    Support Tickets (Last 30d)
                    <span className="text-white font-mono">{tickets}</span>
                  </label>
                  <input 
                    type="range" min="0" max="10" value={tickets}
                    onChange={(e) => setTickets(Number(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500" 
                  />
                </div>
                <div>
                  <label className="flex justify-between text-sm text-slate-400 mb-2">
                    Data Exports (Last 30d)
                    <span className="text-white font-mono">{exports}</span>
                  </label>
                  <input 
                    type="range" min="0" max="20" value={exports}
                    onChange={(e) => setExports(Number(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-green-500" 
                  />
                </div>
              </div>
              
              <div className="mt-8 p-4 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-between transition-colors">
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-widest">Churn Probability</p>
                  <p className={`text-2xl font-black ${getScoreColor(churnScore)}`}>{churnScore}%</p>
                </div>
                <div className="h-10 w-10 rounded-full flex items-center justify-center bg-slate-800">
                    <div className={`w-3 h-3 rounded-full ${churnScore > 50 ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`}></div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="order-1 lg:order-2">
            <h2 className="text-sm font-bold text-indigo-500 tracking-wider uppercase mb-2">03. Rapid Prototyping</h2>
            <h3 className="text-3xl font-bold mb-6">Give Me a Vision, I'll Build the <span className="text-indigo-400">MVP</span>.</h3>
            <p className="text-slate-400 text-lg mb-6">
              When the team needs a "lightweight tool" to solve a specific problem, I don't wait for engineering bandwidth. I build.
            </p>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <CheckCircle className="text-green-500 w-5 h-5 mt-1" />
                <span className="text-slate-300"><strong>48 Hours:</strong> From idea to functional clickable model.</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="text-green-500 w-5 h-5 mt-1" />
                <span className="text-slate-300"><strong>Heuristic Scoring:</strong> Simple algorithms first, ML later.</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="text-green-500 w-5 h-5 mt-1" />
                <span className="text-slate-300"><strong>71% Precision:</strong> Delivering immediate value to the CS team.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Prototyping;