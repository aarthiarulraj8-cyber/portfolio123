import React from 'react';

const Strategy: React.FC = () => {
  return (
    <section id="strategy" className="py-24 bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row gap-12">
          <div className="md:w-1/2">
            <div className="relative rounded-xl overflow-hidden shadow-2xl border border-slate-800 aspect-[4/3] group">
                <img 
                    src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2426&auto=format&fit=crop" 
                    alt="Strategic Presentation" 
                    className="opacity-80 group-hover:opacity-100 transition-opacity duration-500 object-cover w-full h-full"
                />
                <div className="absolute inset-0 bg-indigo-950/20 pointer-events-none mix-blend-multiply"></div>
                <div className="absolute bottom-4 left-4 right-4 bg-slate-950/80 backdrop-blur-sm p-4 rounded-lg border border-slate-800 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <p className="text-white text-sm font-bold">Strategic Narrative Construction</p>
                </div>
            </div>
          </div>
          <div className="md:w-1/2 flex flex-col justify-center">
            <h2 className="text-sm font-bold text-indigo-500 tracking-wider uppercase mb-2">04. Strategy & Communication</h2>
            <h3 className="text-3xl font-bold mb-6">Founder-Grade <span className="text-white">Narratives</span></h3>
            <p className="text-slate-400 mb-6">
              If you need a deck in 2 hours, I'll have version 1 in 30 minutes. My job is to make the founder faster, clearer, and more effective.
            </p>
            <div className="grid grid-cols-2 gap-4">
              {[
                { title: 'Investor Decks', desc: 'Simplifying complex tech into compelling vision.' },
                { title: 'Board Summaries', desc: 'High-signal reporting, no fluff.' },
                { title: 'GTM Plans', desc: 'Measurable experiments & attribution modeling.' },
                { title: 'Ops Handbooks', desc: 'Codifying culture and process.' }
              ].map((item, idx) => (
                <div key={idx} className="p-4 bg-slate-900 rounded-lg border border-slate-800 hover:bg-slate-800 transition-colors hover:border-indigo-500/30">
                  <h5 className="font-bold text-white mb-1">{item.title}</h5>
                  <p className="text-xs text-slate-500">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Strategy;