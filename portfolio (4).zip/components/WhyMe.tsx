import React from 'react';
import { Mail, Linkedin, Phone } from 'lucide-react';

const WhyMe: React.FC = () => {
  return (
    <section id="why-me" className="py-24 bg-indigo-900 relative overflow-hidden">
      <div className="absolute inset-0">
         <img 
          src="https://images.unsplash.com/photo-1557683311-eac922347aa1?q=80&w=2029&auto=format&fit=crop" 
          alt="Abstract Background" 
          className="w-full h-full object-cover opacity-10 mix-blend-overlay"
        />
        <div className="absolute inset-0 bg-indigo-950/90"></div>
      </div>
      <div className="max-w-4xl mx-auto px-4 relative z-10 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">Why Work With Me?</h2>
        <div className="bg-white/5 backdrop-blur-sm p-8 rounded-2xl border border-white/10 mb-10">
          <p className="text-xl text-indigo-100 leading-relaxed mb-6">
            "You need someone who can translate the founder's vision into execution, manage the chaos of scaling, and ensure the company learns faster than the market."
          </p>
          <p className="text-lg text-white font-medium">
            I am that person. I bring the strategic bandwidth of a Chief of Staff and the operational rigor of a Program Manager.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="p-4 bg-indigo-950/50 rounded-lg border border-indigo-500/30 flex flex-col items-center hover:bg-indigo-900/50 transition-colors">
                <Mail className="w-6 h-6 text-indigo-300 mb-2" />
                <span className="text-sm text-indigo-200">Email</span>
                <a href="mailto:aarthiarulraj01@gmail.com" className="text-white font-bold hover:underline">aarthiarulraj01@gmail.com</a>
            </div>
            <div className="p-4 bg-indigo-950/50 rounded-lg border border-indigo-500/30 flex flex-col items-center hover:bg-indigo-900/50 transition-colors">
                <Linkedin className="w-6 h-6 text-indigo-300 mb-2" />
                <span className="text-sm text-indigo-200">LinkedIn</span>
                <a href="https://linkedin.com/in/aarthiarulrajakavera" target="_blank" rel="noopener noreferrer" className="text-white font-bold hover:underline">linkedin.com/in/aarthiarulrajakavera</a>
            </div>
            <div className="p-4 bg-indigo-950/50 rounded-lg border border-indigo-500/30 flex flex-col items-center hover:bg-indigo-900/50 transition-colors">
                <Phone className="w-6 h-6 text-indigo-300 mb-2" />
                <span className="text-sm text-indigo-200">Phone</span>
                <span className="text-white font-bold">+91 7406766595</span>
            </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a href="mailto:aarthiarulraj01@gmail.com" className="px-8 py-4 bg-white text-indigo-900 rounded-full font-bold hover:bg-indigo-50 transition-all shadow-lg transform hover:scale-105 flex items-center justify-center gap-2">
            <Mail className="w-5 h-5" /> Hire Me
          </a>
        </div>
      </div>
    </section>
  );
};

export default WhyMe;